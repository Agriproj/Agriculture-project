(function ($) {
    "use strict";

    // Spinner
    var spinner = function () {
        setTimeout(function () {
            if ($('#spinner').length > 0) {
                $('#spinner').removeClass('show');
            }
        }, 1);
    };
    spinner(0);


    // Fixed Navbar
    $(window).scroll(function () {
        if ($(window).width() < 992) {
            if ($(this).scrollTop() > 55) {
                $('.fixed-top').addClass('shadow');
            } else {
                $('.fixed-top').removeClass('shadow');
            }
        } else {
            if ($(this).scrollTop() > 55) {
                $('.fixed-top').addClass('shadow').css('top', -55);
            } else {
                $('.fixed-top').removeClass('shadow').css('top', 0);
            }
        } 
    });
    
    
   // Back to top button
   $(window).scroll(function () {
    if ($(this).scrollTop() > 300) {
        $('.back-to-top').fadeIn('slow');
    } else {
        $('.back-to-top').fadeOut('slow');
    }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });


    // Testimonial carousel
    $(".testimonial-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 2000,
        center: false,
        dots: true,
        loop: true,
        margin: 25,
        nav : true,
        navText : [
            '<i class="bi bi-arrow-left"></i>',
            '<i class="bi bi-arrow-right"></i>'
        ],
        responsiveClass: true,
        responsive: {
            0:{
                items:1
            },
            576:{
                items:1
            },
            768:{
                items:1
            },
            992:{
                items:2
            },
            1200:{
                items:2
            }
        }
    });


    // vegetable carousel
    $(".vegetable-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1500,
        center: false,
        dots: true,
        loop: true,
        margin: 25,
        nav : true,
        navText : [
            '<i class="bi bi-arrow-left"></i>',
            '<i class="bi bi-arrow-right"></i>'
        ],
        responsiveClass: true,
        responsive: {
            0:{
                items:1
            },
            576:{
                items:1
            },
            768:{
                items:2
            },
            992:{
                items:3
            },
            1200:{
                items:4
            }
        }
    });


    // Modal Video
    $(document).ready(function () {
        var $videoSrc;
        $('.btn-play').click(function () {
            $videoSrc = $(this).data("src");
        });
        console.log($videoSrc);

        $('#videoModal').on('shown.bs.modal', function (e) {
            $("#video").attr('src', $videoSrc + "?autoplay=1&amp;modestbranding=1&amp;showinfo=0");
        })

        $('#videoModal').on('hide.bs.modal', function (e) {
            $("#video").attr('src', $videoSrc);
        })
    });



    // Product Quantity
    $('.quantity button').on('click', function () {
        var button = $(this);
        var oldValue = button.parent().parent().find('input').val();
        if (button.hasClass('btn-plus')) {
            var newVal = parseFloat(oldValue) + 1;
        } else {
            if (oldValue > 0) {
                var newVal = parseFloat(oldValue) - 1;
            } else {
                newVal = 0;
            }
        }
        button.parent().parent().find('input').val(newVal);
    });

})(jQuery);

function changeLanguage(lang) {
    const translations = {
        en: "English",
        kn: "Kannada",
        hi: "Hindi",
        te: "Telugu",
        ta: "Tamil",
    };
    


    // Update the dropdown button to show the selected language
    const languageMenu = document.getElementById("languageMenu");
    languageMenu.textContent = translations[lang];

    // Update the dropdown menu to exclude the selected language
    const dropdownMenu = languageMenu.nextElementSibling;
    dropdownMenu.innerHTML = ""; // Clear existing options

    for (const [key, value] of Object.entries(translations)) {
        if (key !== lang) {
            const option = document.createElement("a");
            option.className = "dropdown-item";
            option.href = "#";
            option.textContent = value;
            option.setAttribute("onclick", `changeLanguage('${key}')`);
            dropdownMenu.appendChild(option);
        }
    }
}

document.addEventListener("DOMContentLoaded", function () {
    const languageMenu = document.getElementById("languageMenu");
    const dropdownMenu = document.querySelector(".dropdown-menu");

    // Toggle dropdown on click
    languageMenu.addEventListener("click", function (event) {
        event.preventDefault(); // Prevent the default anchor behavior
        dropdownMenu.classList.toggle("show");
    });

    // Close dropdown if clicking outside
    document.addEventListener("click", function (event) {
        if (!event.target.closest(".language-dropdown")) {
            dropdownMenu.classList.remove("show");
        }
    });
});

function changeLanguage(languageCode) {
    alert(`Language changed to: ${languageCode}`);
    // Implement your language-changing logic here.
}
